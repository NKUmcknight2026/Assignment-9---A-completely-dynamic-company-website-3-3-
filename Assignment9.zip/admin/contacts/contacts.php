<?php

function getAllContacts() {
    global $db;
    $query = "SELECT * FROM contacts";
    $result = $db->query($query);
    return $result->fetchAll(PDO::FETCH_ASSOC);
}

function getContactById($id) {
    global $db;
    $query = "SELECT * FROM contacts WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

