<?php
require_once 'team.php';  
$id = $_GET['id'];
$member = getTeamMemberById($id); 
?>

<!DOCTYPE html>
<html>
<head>
    <title>Team Member Detail</title>
</head>
<body>
    <h1><?php echo $member['name']; ?></h1>
    <p><strong>Position:</strong> <?php echo $member['position']; ?></p>
    <p><strong>Email:</strong> <?php echo $member['email']; ?></p>
    <p><strong>Phone:</strong> <?php echo $member['phone']; ?></p>
    <a href="edit.php?id=<?php echo $member['id']; ?>">Edit</a>
    <a href="delete.php?id=<?php echo $member['id']; ?>">Delete</a>
    <br>
    <a href="index.php">Back to Team Members List</a>
</body>
</html>
