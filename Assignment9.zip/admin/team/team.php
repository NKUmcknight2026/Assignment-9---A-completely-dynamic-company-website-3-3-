<?php
$host = 'localhost';
$dbname = 'your_database_name';
$username = 'your_username';
$password = 'your_password';

try {
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

function getAllTeamMembers() {
    global $db;  
    $query = "SELECT * FROM team";
    $stmt = $db->query($query);  
    return $stmt->fetchAll(PDO::FETCH_ASSOC);  
}

function getTeamMemberById($id) {
    global $db;
    $query = "SELECT * FROM team WHERE id = :id";  
    $stmt = $db->prepare($query); 
    $stmt->bindParam(':id', $id, PDO::PARAM_INT); 
    $stmt->execute();  
    return $stmt->fetch(PDO::FETCH_ASSOC); 
}

function createTeamMember($data) {
    global $db;
    $query = "INSERT INTO team (name, position, email, phone) VALUES (:name, :position, :email, :phone)";  
    $stmt = $db->prepare($query);  
    $stmt->bindParam(':name', $data['name'], PDO::PARAM_STR);
    $stmt->bindParam(':position', $data['position'], PDO::PARAM_STR);
    $stmt->bindParam(':email', $data['email'], PDO::PARAM_STR);
    $stmt->bindParam(':phone', $data['phone'], PDO::PARAM_STR);
    $stmt->execute();  
}

function updateTeamMember($id, $data) {
    global $db;
    $query = "UPDATE team SET name = :name, position = :position, email = :email, phone = :phone WHERE id = :id";  // SQL query for updating
    $stmt = $db->prepare($query);  
    $stmt->bindParam(':name', $data['name'], PDO::PARAM_STR);
    $stmt->bindParam(':position', $data['position'], PDO::PARAM_STR);
    $stmt->bindParam(':email', $data['email'], PDO::PARAM_STR);
    $stmt->bindParam(':phone', $data['phone'], PDO::PARAM_STR);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);  
    $stmt->execute();  
}

function deleteTeamMember($id) {
    global $db;
    $query = "DELETE FROM team WHERE id = :id";  
    $stmt = $db->prepare($query); 
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);  
    $stmt->execute();  
}
?>
