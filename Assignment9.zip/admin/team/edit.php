<?php
require_once 'team.php';
$id = $_GET['id'];
$member = getTeamMemberById($id);  

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'name' => $_POST['name'],
        'position' => $_POST['position'],
        'email' => $_POST['email'],
        'phone' => $_POST['phone']
    ];
    updateTeamMember($id, $data); 
    header("Location: detail.php?id=" . $id);  
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Team Member</title>
</head>
<body>
    <h1>Edit Team Member</h1>
    <form method="post">
        <label>Name:</label>
        <input type="text" name="name" value="<?php echo $member['name']; ?>" required><br>
        <label>Position:</label>
        <input type="text" name="position" value="<?php echo $member['position']; ?>" required><br>
        <label>Email:</label>
        <input type="email" name="email" value="<?php echo $member['email']; ?>" required><br>
        <label>Phone:</label>
        <input type="text" name="phone" value="<?php echo $member['phone']; ?>" required><br>
        <button type="submit">Save Changes</button>
    </form>
</body>
</html>
