<?php
class Award {
    private $db;

    public function __construct($dbConnection) {
        $this->db = $dbConnection;
    }

    public function createAward($name, $description) {
        $stmt = $this->db->prepare("INSERT INTO awards (name, description) VALUES (?, ?)");
        return $stmt->execute([$name, $description]);
    }

    public function getAwardById($id) {
        $stmt = $this->db->prepare("SELECT * FROM awards WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getAllAwards() {
        $stmt = $this->db->query("SELECT * FROM awards");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function updateAward($id, $name, $description) {
        $stmt = $this->db->prepare("UPDATE awards SET name = ?, description = ? WHERE id = ?");
        return $stmt->execute([$name, $description, $id]);
    }

    public function deleteAward($id) {
        $stmt = $this->db->prepare("DELETE FROM awards WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
?>
