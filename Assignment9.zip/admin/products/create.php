<?php
require_once 'products.php';  

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'name' => $_POST['name'],
        'description' => $_POST['description'],
        'price' => $_POST['price']
    ];
    createProduct($data);  
    header("Location: index.php");  
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create New Product</title>
</head>
<body>
    <h1>Create Product</h1>
    <form method="post">
        <label>Name:</label>
        <input type="text" name="name" required><br>
        <label>Description:</label>
        <textarea name="description" required></textarea><br>
        <label>Price:</label>
        <input type="number" step="0.01" name="price" required><br>
        <button type="submit">Create</button>
    </form>
</body>
</html>
