<?php

function getAllProducts() {
    global $db;
    $query = "SELECT * FROM products";
    $result = $db->query($query);
    return $result->fetchAll(PDO::FETCH_ASSOC);
}

function getProductById($id) {
    global $db;
    $query = "SELECT * FROM products WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function createProduct($data) {
    global $db;
    $query = "INSERT INTO products (name, description, price) VALUES (:name, :description, :price)";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':name', $data['name'], PDO::PARAM_STR);
    $stmt->bindParam(':description', $data['description'], PDO::PARAM_STR);
    $stmt->bindParam(':price', $data['price'], PDO::PARAM_STR);
    $stmt->execute();
}

function updateProduct($id, $data) {
    global $db;
    $query = "UPDATE products SET name = :name, description = :description, price = :price WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':name', $data['name'], PDO::PARAM_STR);
    $stmt->bindParam(':description', $data['description'], PDO::PARAM_STR);
    $stmt->bindParam(':price', $data['price'], PDO::PARAM_STR);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
}

function deleteProduct($id) {
    global $db;
    $query = "DELETE FROM products WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
}
?>
