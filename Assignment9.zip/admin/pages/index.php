<?php
require_once 'pages.php';  
$pages = getAllPages();  
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pages List</title>
</head>
<body>
    <h1>Pages</h1>
    <a href="create.php">Create New Page</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Content</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($pages as $page): ?>
            <tr>
                <td><?php echo $page['id']; ?></td>
                <td><?php echo $page['title']; ?></td>
                <td><?php echo substr($page['content'], 0, 50) . '...'; ?></td>  
                <td>
                    <a href="detail.php?id=<?php echo $page['id']; ?>">View</a>
                    <a href="edit.php?id=<?php echo $page['id']; ?>">Edit</a>
                    <a href="delete.php?id=<?php echo $page['id']; ?>">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
